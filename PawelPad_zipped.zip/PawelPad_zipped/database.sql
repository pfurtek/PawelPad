DROP DATABASE if exists NotepadUsers;
CREATE DATABASE NotepadUsers;
USE NotepadUsers;
CREATE TABLE Usernames (
	usernameID int(11) primary key not null auto_increment,
	login varchar(20) not null
);
CREATE TABLE Passwords (
	usernameID int(11) primary key not null,
	password int(11) not null,
	FOREIGN KEY fk1(usernameID) REFERENCES Usernames(usernameID)
);
CREATE TABLE documents (
	usernameID int(11) not null,
	filename varchar(50) not null,
	FOREIGN KEY fk1(usernameID) REFERENCES Usernames(usernameID)
);