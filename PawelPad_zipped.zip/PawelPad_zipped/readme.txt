Notepad - client
NotepadServer - server